﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calc3;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
    // tu bedziemy przechowywac pierwsza i druga liczbe ktora kliknie uzytkownik
    double pierwszaLiczba = 0;
    double drugaLiczba = 0;
    // tu bedziemy przechowywac obecna operacje wybrana przez uzytkownika czy. +, - itp.
    string operacja = "";

    private void sqrt_Click(object sender, RoutedEventArgs e)
    {   
        // tworzymy zmienna przechowujaca liczbe do pierwiastkowania i bazowo ustawiamy jej wartosc 0;
        double liczbaPierwiastkowana = 0;
        // przypisujemy do zmiennej liczbe kliknieta przez nas ktora chcemy zpierwiastkowac przy okazji konwertujac ja na double i umozliwiajac wprowadzanie liczb z przecinkami
        if (!double.TryParse(ResultBox.Text, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out liczbaPierwiastkowana))
        {
            MessageBox.Show("Błędny format liczby!");
            return;
        }
        // sprawdzenie czy pierwiastkowana liczba nie jest mniejsza od 0, a jezeli jest to wyswietlimy komunkat, pole wyniku zostanie zresetowane a metoda zakonczona
        if (liczbaPierwiastkowana < 0) {
            MessageBox.Show("Nie mozesz pierwiastkowac liczby mniejszej od 0!");
            ResultBox.Text = "0";
            return;
        }
        // obliczamy pierwiastek przy uzyciu wbudowanej biblioteki Math
        liczbaPierwiastkowana = Math.Sqrt(liczbaPierwiastkowana);
        // wyswietlamy wynik po pierwiastkowaniu
        ResultBox.Text = liczbaPierwiastkowana.ToString();
    }

    private void pow_Click(object sender, RoutedEventArgs e)
    {
        // przypisujemy do zmiennej pierwsza kliknieta przez nas liczbe przy okazji konwertujac ja na double i umozliwiajac wprowadzanie liczb z przecinkami
        if (!double.TryParse(ResultBox.Text, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out pierwszaLiczba))
        {
            MessageBox.Show("Błędny format liczby!");
            return;
        }
        // ustawiamy operacje na potega aby uzyc jej pozniej w metodzie equals_Click, po to aby zczytac z niej druga liczbe ktora bedzie wykladnikiem potegi
        operacja = "potega";
        // czyscimy pole by wprowadzic druga liczbe (wykladnik) potegi
        ResultBox.Text = "0";
    }

    private void Clear_Click(object sender, RoutedEventArgs e)
    {
        // czyscimy wszystko do stanu poczatkowego
        ResultBox.Text = "0";
        pierwszaLiczba = 0;
        drugaLiczba = 0;
        operacja = "";
    }

    private void equals_Click(object sender, RoutedEventArgs e)
    {
        // przypisujemy do zmiennej druga kliknieta przez nas liczbe przy okazji konwertujac ja na double i umozliwiajac wprowadzanie liczb z przecinkami
        // liczba która będzie konwertowana zostanie pobrana poprzez podzielenie tekstu z pola ResultBox uzywajac spacji jako separatora a [2] to ostatni element
        // naszej tabliczy czyli druga liczba
        if (!double.TryParse(ResultBox.Text.Split(' ')[2], System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out drugaLiczba))
        {
            MessageBox.Show("Błędny format liczby!");
            return;
        }
        // tworzymy zmienna przechowujaca wynik dzialania
        double wynik = 0;
        // tworzymy warunek wielokrotnego wyboru bazujacego na wartosci zmiennej operacja
        switch (operacja) 
        {   
            case "+":
                wynik = pierwszaLiczba + drugaLiczba;
                break;
            case "/":
                // sprawdzenie czy nie dzielimy przez 0 a jesli tak to wyswietli sie komunikat, pole wyniku zostanie zresetowane a dzialanie metody zakonczone
                if (drugaLiczba == 0) {
                    MessageBox.Show("Nie mozesz dzielic przez 0!");
                    ResultBox.Text = "0";
                    return;
                }
                wynik = pierwszaLiczba / drugaLiczba;
                break;
            case "x":
                wynik = pierwszaLiczba * drugaLiczba;
                break;
            case "-":
                wynik = pierwszaLiczba - drugaLiczba;
                break;
            case "potega":
                wynik = Math.Pow(pierwszaLiczba, drugaLiczba);
                break;
        }
        // wyswietlamy wynik
        ResultBox.Text = wynik.ToString();
    }
    private void operator_Click(object sender, RoutedEventArgs e)
    {
        // rzutujemy klikniety przez nas obiekt na button po to zebysmy mogli np. odczytac jego tekst
        var przycisk = (Button)sender;
        // przypisujemy do zmiennej pierwsza kliknieta przez nas liczbe przy okazji konwertujac ja na double i umozliwiajac wprowadzanie liczb z przecinkami
        if (!double.TryParse(ResultBox.Text, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out pierwszaLiczba))
        {
            MessageBox.Show("Błędny format liczby!");
            return;
        }
        // przypisujemy do zmiennej klikniety przez nas operator a w przypadku gdyby Content naszego przycisku bylby null to zamiast rzucic wyjatku przypisze pustego stringa
        operacja = przycisk.Content.ToString() ?? "";
        // w polu wyniku będziemy wyświetlac również operację aby działanie było sekwencyjne
        ResultBox.Text += " " + operacja + " ";
    }
    // tu bedziemy obslugiwac klikniete liczby od 0 do 9
    private void number_Click(object sender, RoutedEventArgs e)
    {
        // rzutujemy klikniety przez nas obiekt na button po to zebysmy mogli np. odczytac jego tekst
        var przycisk = (Button)sender;
        // po kliknieciu kropki sprawdzamy czy w liczbie jest juz kropka
        if (przycisk.Content.ToString() == ".") {
            // jesli brakuje kropki w polu wynikowym to ja dodajemy
            if (!ResultBox.Text.Contains(".")) {
                ResultBox.Text += ".";
            }
            return;
        }
        // logika powodujaca wyczyszczenie naszego textboxa wyniku jesli aktualny tekst jest rowny 0 lub zakonczylismy dzialanie poprzez klikniecie = 
        if (ResultBox.Text == "0" || operacja == "=") {
            ResultBox.Text = "";
        }
        // dodajemy kliknieta cyfre do pola tekstowego
        ResultBox.Text += przycisk.Content.ToString();
    }
}