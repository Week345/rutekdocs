﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KolkoKrzyzykZad8;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    // Tablica 3x3 przycisków reprezentujących pola gry
    private Button[,] buttons = new Button[3, 3];
    // Flaga określająca, czy ruch należy do gracza "X"
    private bool isXTurn = true;
    public MainWindow()
    {
        InitializeComponent();
        CreateButtons();
    }
    private void CreateButtons() {
        RozkladGry.Children.Clear();
        for (int row = 0; row < 3; row++)       // Iteracja po wierszach
        {
            for (int col = 0; col < 3; col++)   // Iteracja po kolumnach
            {
                Button btn = new Button
                {
                    FontSize = 32,                 // Duża czcionka dla lepszej widoczności X i O
                    Tag = new Point(row, col)      // Przechowujemy pozycję przycisku
                };
                btn.Click += Button_Click;         // Obsługa kliknięcia
                buttons[row, col] = btn;           // Dodajemy przycisk do tablicy
                RozkladGry.Children.Add(btn);        // Dodajemy przycisk do siatki w UI
            }
        }
    }
    // Obsługuje kliknięcie na dowolny przycisk
    private void Button_Click(object sender, RoutedEventArgs e)
    {
        Button btn = sender as Button; // Rzutowanie obiektu sender na przycisk

        if (btn.Content != null) return; // Ignorujemy kliknięcie, jeśli już coś tam jest (X lub O)

        // Ustawiamy X lub O w zależności od tury
        btn.Content = isXTurn ? "X" : "O";

        // Zmieniamy turę
        isXTurn = !isXTurn;

        // Sprawdzamy, czy ktoś wygrał
        CheckWinner();
    }

    // Sprawdza, czy jest zwycięzca
    private void CheckWinner()
    {
        string winner = null; // String będzie odpowiedzialny później za przechowanie literki zwycięzcy X lub O

        for (int i = 0; i < 3; i++)
        {
            // Sprawdzenie wierszy
            if (buttons[i, 0].Content != null &&
                buttons[i, 0].Content == buttons[i, 1].Content &&
                buttons[i, 1].Content == buttons[i, 2].Content)
            {
                winner = buttons[i, 0].Content.ToString(); // Ustawienie zwycięzcy
            }

            // Sprawdzenie kolumn
            if (buttons[0, i].Content != null &&
                buttons[0, i].Content == buttons[1, i].Content &&
                buttons[1, i].Content == buttons[2, i].Content)
            {
                winner = buttons[0, i].Content.ToString(); // Ustawienie zwycięzcy
            }
        }

        // Sprawdzenie przekątnej (głównej)
        if (buttons[0, 0].Content != null &&
            buttons[0, 0].Content == buttons[1, 1].Content &&
            buttons[1, 1].Content == buttons[2, 2].Content)
        {
            winner = buttons[0, 0].Content.ToString(); // Ustawienie zwycięzcy
        }

        // Sprawdzenie przekątnej (drugiej)
        if (buttons[0, 2].Content != null &&
            buttons[0, 2].Content == buttons[1, 1].Content &&
            buttons[1, 1].Content == buttons[2, 0].Content)
        {
            winner = buttons[0, 2].Content.ToString(); // Ustawienie zwycięzcy
        }

        // Jeżeli znaleziono zwycięzcę
        if (winner != null)
        {
            MessageBox.Show($"{winner} wygrywa!"); // Komunikat o zwycięstwie
            DisableButtons(); // Dezaktywacja przycisków
        }
        else if (IsDraw()) // Sprawdzenie remisu
        {
            MessageBox.Show("Remis!"); // Komunikat o remisie
        }
    }

    // Sprawdza, czy wszystkie pola są zajęte, czyli remis
    private bool IsDraw()
    {
        foreach (Button btn in buttons)
        {
            if (btn.Content == null)
                return false; // Jeśli jest choć jedno puste pole, to nie ma remisu
        }
        return true; // w przeciwnym przypadku zwracamy true
    }

    // Dezaktywuje wszystkie przyciski po zakończeniu gry
    private void DisableButtons()
    {
        foreach (Button btn in buttons)
        {
            btn.IsEnabled = false;
        }
    }

    // Obsługuje kliknięcie przycisku "Restart"
    private void Restart_Click(object sender, RoutedEventArgs e)
    {
        isXTurn = true; // Resetowanie tury
        CreateButtons();   // Ponowne utworzenie pustej planszy
    }
}