﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace LogowanieZad7;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    // Ścieżki do plików
    private readonly string usersFile = "user.txt";
    private readonly string logFile = "events.log";
    public MainWindow()
    {
        InitializeComponent();
        zaloguj.Focus();
        anuluj.Focus();
        Keyboard.Focus(zaloguj);
        Keyboard.Focus(anuluj);

        // Jeśli plik user.txt nie istnieje – utwórz go z domyślnym kontem
        if (!File.Exists(usersFile))
        {
            // Szyfrowanie loginu i hasła szyfrem Cezara (+21)
            string encryptedLogin = CaesarEncrypt("admin", 21);
            string encryptedPassword = CaesarEncrypt("adminpas", 21);
            string line = $"{encryptedLogin};{encryptedPassword}";

            // Zapis do pliku
            File.WriteAllText(usersFile, line);

            // Informacja dla użytkownika
            MessageBox.Show("Plik użytkowników został utworzony z domyślnym kontem:\nLogin: admin\nHasło: adminpas");
        }
        // Tworzenie pustego pliku events.log (jeśli nie istnieje)
        if (!File.Exists(logFile))
        {
            File.WriteAllText(logFile, ""); // tworzy pusty plik
        }
    }

    private async void Button_Click(object sender, RoutedEventArgs e)
    {
        // Pobranie i oczyszczenie wpisanych danych
        string login = loginBox.Text.Trim();
        string password = passBox.Text.Trim();

        // Sprawdzenie czy pola są puste
        if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
        {
            MessageBox.Show("Wprowadź login i hasło.");
            return;
        }

        // Sprawdzenie istnienia pliku z użytkownikami
        if (!File.Exists(usersFile))
        {
            MessageBox.Show("Plik użytkowników nie istnieje.");
            return;
        }

        var lines = File.ReadAllLines(usersFile); // Wczytanie wszystkich linii z pliku
        bool loginFound = false; // Flaga, czy znaleziono login

        foreach (var line in lines)
        {
            var parts = line.Split(';'); // Podział linii na login i hasło
            if (parts.Length != 2) continue;

            // Deszyfrowanie loginu i hasła
            string decryptedLogin = CaesarDecrypt(parts[0], 21);
            string decryptedPassword = CaesarDecrypt(parts[1], 21);

            // Sprawdzenie czy login pasuje
            if (decryptedLogin == login)
            {
                loginFound = true;

                // Sprawdzenie czy hasło również pasuje
                if (decryptedPassword == password)
                {
                    LogEvent($"Poprawne logowanie użytkownika {login}"); // Zapis do logu
                    MessageBox.Show("Zalogowano pomyślnie!");
                    return;
                }
                else
                {
                    await HighlightInvalid(passBox); // Podświetlenie błędnego hasła
                    LogEvent($"Nieprawidłowe logowanie loginem {login}, nieprawidłowy hasło");
                    return;
                }
            }
        }

        // Jeśli nie znaleziono loginu
        if (!loginFound)
        {
            await HighlightInvalid(loginBox); // Podświetlenie błędnego loginu
            LogEvent($"Nieprawidłowe logowanie loginem {login}, nieprawidłowy login");
        }
    }
    private async Task HighlightInvalid(Control control)
    {
        var originalBrush = control.Background; // Zapisanie oryginalnego koloru
        control.Background = Brushes.Red; // Ustawienie koloru czerwonego
        await Task.Delay(2000); // Odczekanie 2 sekundy
        control.Background = originalBrush; // Przywrócenie oryginalnego koloru
    }

    // Zapis zdarzenia logowania do pliku logów
    private void LogEvent(string message)
    {
        try
        {
            string logLine = $"{DateTime.Now:dd/MM/yyyy  HH:mm} {message}";
            File.AppendAllText(logFile, logLine + Environment.NewLine); // dopisuje linię do pliku logów
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Błąd zapisu logu: {ex.Message}");
        }
    }

    // Szyfr deszyfrujący (odwrócenie szyfru Cezara)
    private string CaesarDecrypt(string input, int key)
    {
        return CaesarEncrypt(input, 26 - key); // Deszyfrowanie to szyfrowanie z odwrotnym kluczem
    }

    // Uniwersalny szyfr Cezara (dla liter)
    private string CaesarEncrypt(string input, int key)
    {
        StringBuilder sb = new StringBuilder();

        foreach (char c in input)
        {
            if (char.IsLetter(c)) // Obsługa tylko liter
            {
                char baseChar = char.IsUpper(c) ? 'A' : 'a';
                sb.Append((char)((c - baseChar + key) % 26 + baseChar)); // Przesunięcie znaku
            }
            else
            {
                sb.Append(c); // Pozostałe znaki bez zmian (np. cyfry, spacje, znaki interpunkcyjne)
            }
        }

        return sb.ToString();
    }
    private void Button_Click_1(object sender, RoutedEventArgs e)
    {
        Application.Current.Shutdown(); // kliknięcie przycisku spowoduje zakończenie działania aplikacji
    }
}
